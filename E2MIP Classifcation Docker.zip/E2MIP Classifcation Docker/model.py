from torch import nn
from ptflops import get_model_complexity_info
class SeparableConv3D(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, padding):
        super(SeparableConv3D, self).__init__()
        self.depthwise = nn.Conv3d(in_channels, in_channels, kernel_size=kernel_size, padding=padding, groups=in_channels)
        self.pointwise = nn.Conv3d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x

class Model(nn.Module):
    def __init__(self, input_size, num_classes):
        super(Model, self).__init__()
        self.input_size = input_size

        self.conv_layer1 = self._conv_layer_set(input_size, 32)
        self.conv_layer2 = self._conv_layer_set(32, 64)
        self.fc1 = nn.Linear(64000, 128)
        self.fc2 = nn.Linear(128, num_classes)
        self.relu = nn.LeakyReLU()
        self.batch = nn.BatchNorm1d(128)
        self.drop = nn.Dropout(p=0.5)#0.15

        self.outact = nn.Softmax(dim=-1)

    def _conv_layer_set(self, in_c, out_c):
        conv_layer = nn.Sequential(
            SeparableConv3D(in_c, out_c, kernel_size=(3, 3, 3), padding=0),
            nn.LeakyReLU(),
            nn.MaxPool3d((2, 2, 2)),
        )
        return conv_layer

    def forward(self, x):
        out = self.conv_layer1(x)
        out = self.conv_layer2(out)
        out = out.view(out.size(0), -1)
        out = self.fc1(out)
        out = self.relu(out)
        if out.shape[0]>1:
            out = self.batch(out)
        out = self.drop(out)
        out = self.fc2(out)
        out = self.outact(out)
        return out


