#!/bin/bash

# Set default values for the paths (can be overridden by command line arguments)
TESTING_DATA_PATH="../mnt/query_data"
TESTING_DATA_SOLUTION_PATH="../mnt/testing_data_solution_classification"
MODEL_PATH="../mnt/training_results/Model.pth"  # Default model path, can be overridden

# Parse the input arguments to allow dynamic input paths
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --testing_data_path) TESTING_DATA_PATH="$2"; shift ;;
        --testing_data_solution_path) TESTING_DATA_SOLUTION_PATH="$2"; shift ;;
        --model_path) MODEL_PATH="$2"; shift ;;
    esac
    shift
done

# Set the environment variables for CUDA (if needed)
export CUDA_VISIBLE_DEVICES=0

# Run the Python inference script with appropriate arguments
python test.py \
    --testing_data_path "$TESTING_DATA_PATH" \
    --testing_data_solution_path "$TESTING_DATA_SOLUTION_PATH" \
    --model_path "$MODEL_PATH" \


echo "Inference completed. Model accuracy and metrics have been calculated."
