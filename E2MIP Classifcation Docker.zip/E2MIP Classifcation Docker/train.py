import torch
import torchvision.transforms as transforms
from dataloading_train import load_training_data
from classification_train import train_loop_class
    
if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--batch_size', default=32, type=int)
    parser.add_argument('--training_results',default="../mnt/training_results",help="Set the path for storing results", type=str)

    parser.add_argument('--training_data_path', type=str, default="../mnt/training_data")
    parser.add_argument('--lr', default=0.001, type=float, help="Learning rate")
    args = parser.parse_args()
    print(args)

    if args.training_data_path is None:
        raise TypeError("Please specify the path to the training data by setting the parameter --training_data_path=\"path_to_trainingdata\"")
    
    # Preprocess training data. When first time called, data is preprocessed and saved to "my_training_data".
    # When this folder exists, data is loaded from it directly.
    train_loader, val_loader = load_training_data(args)
    print("Number of samples in datasets:")
    print(" training: " + str(len(train_loader.dataset)))
    print(" validation: " + str(len(val_loader.dataset)))
    print("Shape of data:")
    print(" image: " + str(next(iter(train_loader))[0].shape))
    print(" target malignancy label: " + str(next(iter(train_loader))[1].shape))
    
    # Train model and save best-performing model at model_path.
    model_path = train_loop_class(train_loader, val_loader, args)

