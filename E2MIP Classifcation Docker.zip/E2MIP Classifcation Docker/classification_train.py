import torch
from torch import nn
from sklearn.metrics import confusion_matrix
import numpy as np
import os
from torchmetrics import AUROC, F1Score, Precision, Recall
import datetime
import matplotlib.pyplot as plt
from ptflops import get_model_complexity_info
from torch.nn import DataParallel
from tqdm import tqdm 
import pandas as pd
from torchvision import models
import torch.optim as optim
from model import Model

from torch.optim import lr_scheduler


def train_loop_class(train_loader, val_loader, args):
    input_channels = next(iter(train_loader))[0].shape[1]
    num_classes = next(iter(train_loader))[1].shape[-1]
    model = Model(1,2)

    

    mac, params = get_model_complexity_info(model, input_res=(1, 48,48,48))
    print(mac)	
    
    model_name = model.__class__.__name__
    
    # model.to(f'cuda:{model.device_ids[0]}')
    # model=DataParallel(model, device_ids=[1])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model = DataParallel(model)
    optimizer = torch.optim.SGD(model.parameters(), lr=args.lr,weight_decay=0)  # 0.001
    #scheduler = lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.1) 
    log = pd.DataFrame(columns= ['epoch','tr_acc','tr_loss','tr_auc','tr_recall','val_acc','val_loss','val_auc','val_f1','val_recall','lr','batch_size'])

    tr_accs,tr_losses,tr_aucs,tr_f1ss,tr_precisions,tr_recalls = [],[],[],[],[],[]
    val_accs,val_loss,val_aucs,val_f1ss,val_precisions,val_recalls = [],[],[],[],[],[]
    best_val = 0.0
    for ep in range(args.epochs):
        print("Epoch " + str(ep))
        print("Training")
        model, tr_acc, tr_loss, tr_auc, tr_f1s, tr_precision, tr_recall = train_fnc(model, train_loader, optim=optimizer)
        tr_accs.append(tr_acc)
        tr_losses.append(tr_loss.cpu().detach().numpy())
        tr_aucs.append(tr_auc.cpu().detach().numpy())
        tr_f1ss.append(tr_f1s.cpu().detach().numpy())
        tr_precisions.append(tr_precision.cpu().detach().numpy())
        tr_recalls.append(tr_recall.cpu().detach().numpy())
        val_acc,val_loss, val_auc, val_f1s, val_precision, val_recall = val_fnc(model, val_loader)
        val_accs.append(val_acc)
        val_aucs.append(val_auc.cpu().detach().numpy())
        val_f1ss.append(val_f1s.cpu().detach().numpy())
        val_precisions.append(val_precision.cpu().detach().numpy())
        val_recalls.append(val_recall.cpu().detach().numpy())
        log = pd.DataFrame({
            'epochs':[ep],
            'tr_acc':[tr_acc],
            'tr_loss':[tr_loss.cpu().detach().numpy()],
            'tr_auc':[tr_auc.cpu().detach().numpy()],
            'tr_recall':[tr_recall.cpu().detach().numpy()],
            'val_acc':[val_acc],
            'val_auc':[val_auc.cpu().detach().numpy()],
            'val_f1':[val_f1s.cpu().detach().numpy()],
            'val_recall':[val_recall.cpu().detach().numpy()],
            'lr':[args.lr],
	    'batch_size':[args.batch_size],
            'val_loss':[val_loss.cpu().detach().numpy()]
            
        })
	

		
        if val_f1s.cpu().detach().numpy() > best_val:
    
    # Ensure the directory exists
            os.makedirs("../mnt/training_results", exist_ok=True)
            
            # Print the correct directory path
            print("Directory ../mnt/training_results created or already exists.")
            
            # Save the model's state
            torch.save({
                'epoch': ep + 1,
                'state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict()
            }, "../mnt/training_results/" + model_name + ".pth")
            
            # Indicate that a new best model has been saved
            print(f"Saving model to: ../mnt/training_results/{model_name}.pth")
            
            best_val = val_f1s.cpu().detach().numpy()
    
    return model_name + ".pth"

def loss_fcn(gt, pred):
	
    L_pred = nn.CrossEntropyLoss()(torch.squeeze(pred, dim=-1), gt)
    return L_pred
def train_fnc(trainmodel, data_loader, optim):
    trainmodel.train()
    auc,f1s,precision,recall = [],[],[],[]
    correct_mal = 0
    tr_loss = 0
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    pbar=tqdm(total=len(data_loader))
    for i, (x, y_mal) in tqdm(enumerate(data_loader)):
        x, y_mal = x.to(device, dtype=torch.float), y_mal.to(device, dtype=torch.float)

        optim.zero_grad()
        pred_mal = trainmodel(x)

        loss = loss_fcn(y_mal, pred_mal)

        loss.backward()
        optim.step()

        mal_confusion_matrix = confusion_matrix(np.argmax(pred_mal.cpu().detach().numpy(), axis=1),
                                                np.argmax(y_mal.cpu().detach().numpy(), axis=1),
                                                labels=[0, 1])
        mal_correct = sum(np.diagonal(mal_confusion_matrix, offset=0))

        correct_mal += mal_correct
        tr_loss += loss
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        auroc = AUROC(task="multiclass", num_classes=2).to(device)
        auc.append(auroc(pred_mal, torch.argmax(y_mal, dim=1)))
        f1score = F1Score(task="multiclass", num_classes=2).to(device)
        f1s.append(f1score(pred_mal, torch.argmax(y_mal, dim=1)))
        precisionscore = Precision(task="multiclass", average='macro', num_classes=2).to(device)
        precision.append(precisionscore(pred_mal, torch.argmax(y_mal, dim=1)))
        recallscore = Recall(task="multiclass", average='macro', num_classes=2).to(device)
        recall.append(recallscore(pred_mal, torch.argmax(y_mal, dim=1)))
        pbar.update()
    pbar.close()    

    return trainmodel, \
        correct_mal / len(data_loader.dataset), \
        tr_loss / len(data_loader.dataset), \
        sum(auc) / len(auc), \
        sum(f1s) / len(f1s), \
        sum(precision) / len(precision), \
        sum(recall) / len(recall)

def val_fnc(testmodel, data_loader):
    testmodel.eval()
    auc,f1s,precision,recall = [],[],[],[]
    correct_mal = 0
    val_loss=0
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    with torch.no_grad():
        for i, (x, y_mal) in enumerate(data_loader):
            x, y_mal = x.to(device, dtype=torch.float), y_mal.to(device, dtype=torch.float)

            pred_mal = testmodel(x)
            loss=loss_fcn(y_mal,pred_mal)
            val_loss+=loss
	    

            
            mal_confusion_matrix = confusion_matrix(np.argmax(pred_mal.cpu().detach().numpy(), axis=1),
                                                    np.argmax(y_mal.cpu().detach().numpy(), axis=1),
                                                    labels=[0, 1])
            mal_correct = sum(np.diagonal(mal_confusion_matrix, offset=0))
            correct_mal += mal_correct
            auroc = AUROC(task="multiclass", num_classes=2).to(device)
            auc.append(auroc(pred_mal, torch.argmax(y_mal, dim=1)))
            f1score = F1Score(task="multiclass", num_classes=2).to(device)
            f1s.append(f1score(pred_mal, torch.argmax(y_mal, dim=1)))
            precisionscore = Precision(task="multiclass", average='macro', num_classes=2).to(device)
            precision.append(precisionscore(pred_mal, torch.argmax(y_mal, dim=1)))
            recallscore = Recall(task="multiclass", average='macro', num_classes=2).to(device)
            recall.append(recallscore(pred_mal, torch.argmax(y_mal, dim=1)))
         
    return correct_mal / len(data_loader.dataset),\
        val_loss /len(data_loader.dataset), \
        sum(auc) / len(auc), \
        sum(f1s) / len(f1s), \
        sum(precision) / len(precision), \
        sum(recall) / len(recall)
