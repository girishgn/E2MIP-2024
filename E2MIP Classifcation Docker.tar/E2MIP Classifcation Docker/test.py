import torch
import torchvision.transforms as transforms
from dataloading_test import load_testing_data
from classification_test import test_model

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--batch_size', default=32, type=int)
    parser.add_argument('--testing_data_path', type=str, default="../mnt/query_data", help="Set the path to testing dataset")
    parser.add_argument('--testing_data_solution_path', default="../mnt/testing_data_solution_classification", type=str, help="Set the path to solution of testing dataset")
    parser.add_argument('--model_path', type=str, required=False,default="../mnt/training_results/Model.pth" ,help="Set the path of the model to be tested")
    args = parser.parse_args()
    print(args)

    if args.testing_data_path is None:
        raise TypeError("Please specify the path to the testing data by setting the parameter --testing_data_path=\"path_to_testingdata\"")
    
    # Preprocess testing data. When first time called, data is preprocessed and saved to "my_testing_data"; this takes a considerable amount of time.
    # When this folder exists, data is loaded from it directly.
    test_loader = load_testing_data(args)
    print("Number of samples in datasets:")
    print(" testing: " + str(len(test_loader.dataset)))

    # Testing data is being predicted and predictions are being saved in folder "testing_data_prediction_classification".
    test_model(test_loader, args)
    print("Model prediction completed.")
    
    if args.testing_data_solution_path is None:
        raise TypeError("Please specify the path to the testing solution/ground truth data by setting the parameter --testing_data_solution_path=\"path_to_testingdata_solution\"")
    
    """# Accuracy metric is being calculated between data in folder args.testing_data_solution_path and "testing_data_prediction_classification".
    test_acc, test_auc, test_f1s, test_precision, test_recall = calculateAccuracy(args)
    print("Testing accuracy: " + str(test_acc))
    print("Testing AUC: " + str(test_auc))
    print("Testing F1: " + str(test_f1s))
    print("Testing Precision: " + str(test_precision))
    print("Testing Recall: " + str(test_recall)) """
