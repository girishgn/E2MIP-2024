#!/bin/bash

# Set default values for the paths (can be overridden by command line arguments)
TRAINING_DATA_PATH="../mnt/training_data"
TRAINING_RESULTS_PATH="../mnt/training_results"

# Parse the input arguments to allow dynamic input paths
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --training_data) TRAINING_DATA_PATH="$2"; shift ;;
        --training_results) TRAINING_RESULTS_PATH="$2"; shift ;;
    esac
    shift
done

# Set the environment variables for CUDA (if needed)
export CUDA_VISIBLE_DEVICES=0

# Run the Python training script with appropriate arguments
python train.py \
    --training_data_path "$TRAINING_DATA_PATH" \
    --training_results  "$TRAINING_RESULTS_PATH" \


# Move the best model to the training results path


