#!/bin/bash

# Set default values for the paths (can be overridden by command line arguments)
TRAINING_DATA_PATH="../mnt/training_data"
TRAINING_RESULTS_PATH="../mnt/training_results"
    
# Parse the input arguments to allow dynamic input paths
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --data) TRAINING_DATA_PATH="$2"; shift ;;
        --output) TRAINING_RESULTS_PATH="$2"; shift ;;
    esac
    shift
done

# Check if the required arguments are provided



# Run the Python training script with appropriate arguments
python train.py \
    --training_data_path "$TRAINING_DATA_PATH" \
    

echo "Training completed. Results saved at: $TRAINING_RESULTS_PATH"
