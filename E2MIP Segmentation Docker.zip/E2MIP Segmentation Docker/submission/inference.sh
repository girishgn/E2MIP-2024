#!/bin/bash

# Set default values for the paths (can be overridden by command line arguments)
TESTING_DATA_PATH="../mnt/query_data"
TESTING_DATA_SOLUTION_PATH="../mnt/testing_data_solution_segmentation"

# Parse the input arguments to allow dynamic input paths
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --testing_data_path) TESTING_DATA_PATH="$2"; shift ;;
        --testing_data_solution_path) TESTING_DATA_SOLUTION_PATH="$2"; shift ;;
    esac
    shift
done

# Check if the required arguments are provided
# Run the Python testing script with appropriate arguments
python test.py \
    --testing_data_path "$TESTING_DATA_PATH" \
    --testing_data_solution_path "$TESTING_DATA_SOLUTION_PATH"

echo "Inference completed. Predictions saved in the specified directory."
