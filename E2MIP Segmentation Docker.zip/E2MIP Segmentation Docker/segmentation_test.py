import os
import shutil
import torch
from torchmetrics import Dice
import numpy as np
import nibabel as nib
# from separablemodel3D im
# port SeparableUNet3D
from tqdm import tqdm
from torch.nn import DataParallel
from model import Model
from tqdm import tqdm

def test_model(dataloader, args):
    

    model = Model()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    model_name = model.__class__.__name__
# Safely load the model state_dict
    checkpoint = torch.load(
        "../mnt/training_results/" + model_name + ".pth", 
        map_location=device, 
        weights_only=True  # Recommended for safety in future PyTorch releases
    )
    state = checkpoint['state_dict'] 

# Load the weights into the model
    # Remove the 'module' prefix from keys
    state_dict = {key.replace('module.', ''): value for key, value in state.items()}

    model.load_state_dict(state_dict)

    model.to(device)

    os.makedirs("../mnt/testing_data_prediction_segmentation",exist_ok=True)
    test_fnc_final(model, dataloader, args)


def test_fnc_final(test_model, data_loader, args):
    test_model.eval()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    scan_ID=[]
  
    with torch.no_grad():
        for i, (x, scan_ID, orig_size) in tqdm(enumerate(data_loader)):
           
            if not os.path.isdir("../mnt/testing_data_prediction_segmentation/scan_" + str(scan_ID[0][0].item())):
                os.makedirs("../mnt/testing_data_prediction_segmentation/scan_" + str(scan_ID[0][0].item()))

            x = x.to(device, dtype=torch.float)
            x[x < -1000] = -1000
            x[x > 1000] = 1000
            x = (x - (-1000)) / (1000 - (-1000))

            preds = []
            for pi in np.arange(start=0, stop=x.shape[0], step=args.batch_size):
                if (pi + args.batch_size) >= x.shape[0]:
                    pred_pi_seg = test_model(x[pi:])
                else:
                    pred_pi_seg = test_model(x[pi:pi + args.batch_size])
                preds.append(pred_pi_seg)
            pred_seg = torch.asarray(preds[0])
            for allpreds in range(len(preds) - 1):
                pred_seg = torch.cat([pred_seg, torch.asarray(preds[allpreds + 1])], dim=0)
            depth_step = int(pred_seg.shape[0] / args.patch_size[0])
            plot_vol_seg = np.zeros((512, 512, depth_step * args.patch_size[2]))
            counteridx = 0
            for yi in range(8):
                for xi in range(8):
                    for depthi in range(depth_step):
                        plot_vol_seg[yi * args.patch_size[0]:(yi + 1) * args.patch_size[0], xi * args.patch_size[1]:(xi + 1) * args.patch_size[1],
                        depthi * args.patch_size[2]:(depthi + 1) * args.patch_size[2]] = pred_seg[counteridx, 0, :, :, :].cpu()
                        counteridx += 1
            plot_vol_seg = plot_vol_seg[:, :, :orig_size[0][-1]]
            pred_seg_nii = nib.Nifti1Image(plot_vol_seg, affine=np.eye(4))
            nib.save(pred_seg_nii,
                     "../mnt/testing_data_prediction_segmentation/scan_" + str(scan_ID[0][0].item()) + "/prediction_total.nii")
            print("saved prediction " + str(i) + "/" + str(len(data_loader)))

        del x
        del preds
        del pred_seg
        del plot_vol_seg
        del pred_seg_nii

"""def calculateDice(args):
    dc = 0.0
    counter = 0
    dice = Dice(average='micro',ignore_index=0)
    for scan_file in os.listdir(args.testing_data_solution_path):
        y_mask = torch.from_numpy(
            nib.load(args.testing_data_solution_path + "/" + scan_file + "/segmentation_total.nii").get_fdata()).int()
        pred_seg = torch.from_numpy(
            nib.load("./mnt/testing_data_prediction_segmentation/" + scan_file + "/prediction_total.nii").get_fdata())
        print("Dice score of " + str(scan_file) + ": " + str(dice(pred_seg, y_mask).item()))
        dc += dice(pred_seg, y_mask)
        counter += 1

    return dc / counter"""

