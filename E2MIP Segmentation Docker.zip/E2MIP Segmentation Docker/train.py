from dataloading_train import load_training_data
from segmentation_train import train_loop_seg

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--batch_size', default=16, type=int)
    parser.add_argument('--patch_size', nargs='+', type=int, default=[64,64,64], help="Size of 3D boxes cropped out of CT volumes as model input")
    parser.add_argument('--training_data_path', type=str, default="../mnt/training_data", help="Set the path to training dataset")
    parser.add_argument('--lr', default=0.001, type=float, help="Learning rate")
    parser.add_argument('--num_classes', type=int, default=1, help="Number of classes / number of output layers")
    args = parser.parse_args()
    print(args)

    if args.training_data_path is None:
        raise TypeError("Please specify the path to the training data by setting the parameter --training_data_path=\"path_to_trainingdata\"")

    # Preprocess training data.
    train_loader, val_loader = load_training_data(args)
    print("Number of samples in datasets:")
    print(" training: " + str(len(train_loader.dataset)))
    print(" validation: " + str(len(val_loader.dataset)))
    print("Shape of data:")
    print(" image: " + str(next(iter(train_loader))[0].shape))
    print(" ROI mask: " + str(next(iter(train_loader))[1].shape))

    # Train model and save best performing model at model_path.
    model_path = train_loop_seg(train_loader, val_loader, args)
    print(f"Training complete. Model saved at: {model_path}")
